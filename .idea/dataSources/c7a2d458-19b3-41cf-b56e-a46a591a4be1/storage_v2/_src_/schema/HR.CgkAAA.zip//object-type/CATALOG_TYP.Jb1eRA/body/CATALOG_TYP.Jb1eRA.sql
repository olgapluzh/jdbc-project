create TYPE BODY CATALOG_TYP 
    AS 
    MEMBER FUNCTION GETCATALOGNAME 
    RETURN VARCHAR 
    AS 
    BEGIN
    -- Return the category name from the supertype
    RETURN self.category_name;
  END; 
    MEMBER FUNCTION CATEGORY_DESCRIBE 
    RETURN VARCHAR 
    AS 
    BEGIN
    RETURN 'catalog_typ';
  END; 
    END 
;
/

